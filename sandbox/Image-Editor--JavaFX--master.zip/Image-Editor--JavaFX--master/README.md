Image-Editor--JavaFX-
=====================

This was a little project to get familiar with javafx, but I decided to work on more important things.
